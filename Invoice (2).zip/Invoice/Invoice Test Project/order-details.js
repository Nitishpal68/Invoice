// Order Details Page JavaScript
document.addEventListener('DOMContentLoaded', function () {
    // Get order details from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
    const status = urlParams.get('status');

    if (orderId && status) {
        populateOrderDetails(orderId, status);
    } else {
        // Fallback to default content if no parameters
        populateOrderDetails('123456', 'Delivered');
    }
});

// Function to populate order details
function populateOrderDetails(orderId, status) {
    // Update order number and status
    const orderNumberElement = document.getElementById('order-number');
    const orderStatusElement = document.getElementById('order-status');
    const orderBreakdownBody = document.getElementById('order-breakdown-body');

    if (orderNumberElement) {
        orderNumberElement.textContent = `Order # ${orderId}`;
    }

    if (orderStatusElement) {
        orderStatusElement.textContent = `Status: ${status}`;
        
        // Add status-specific styling
        orderStatusElement.className = 'order-status';
        if (status === 'Delivered') {
            orderStatusElement.classList.add('status-delivered');
        } else if (status === 'Refund') {
            orderStatusElement.classList.add('status-refund');
        }
    }

    // Populate order breakdown table
    if (orderBreakdownBody) {
        orderBreakdownBody.innerHTML = generateOrderBreakdownHTML(orderId, status);
    }

    // Update page title
    document.title = `Order #${orderId} Details - My School Lunch`;
}

// Function to generate order breakdown HTML
function generateOrderBreakdownHTML(orderId, status) {
    let html = '';

    // Add order items
    html += `
        <tr class="order-breakdown-data">
            <td>6-Inch Turkey Sub</td>
            <td>1</td>
            <td>$9.95</td>
        </tr>
        <tr class="order-breakdown-summary">
            <td>600ml Coca Cola</td>
            <td>1</td>
            <td>$4.95</td>
        </tr>
        <tr class="order-breakdown-data">
            <td style="font-weight: bold !important;">Subtotal</td>
            <td>2</td>
            <td>$14.90</td>
        </tr>
    `;

    // Add refund row if status is Refund
    if (status === 'Refund') {
        html += `
            <tr class="order-breakdown-refund">
                <td style="font-weight: bold;">Refund</td>
                <td></td>
                <td>($14.90)</td>
            </tr>
        `;
    }

    // Add commission and totals
    html += `
        <tr class="order-breakdown-summary">
            <td style="font-weight: bold;">Commission</td>
            <td>16%</td>
            <td>($2.38)</td>
        </tr>
        <tr class="order-breakdown-data">
            <td style="font-weight: bold;">GST on Commission</td>
            <td></td>
            <td>($0.21)</td>
        </tr>
        <tr class="order-breakdown-data">
            <td style="font-weight: bold;">Total Payable</td>
            <td></td>
            <td>${status === 'Refund' ? '($17.49)' : '$12.36'}</td>
        </tr>
    `;

    return html;
}
