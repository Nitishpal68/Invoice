// Invoice Page JavaScript
document.addEventListener('DOMContentLoaded', function () {
    // Add any interactive functionality here if needed

    // Example: Add print functionality
    function printInvoice() {
        window.print();
    }

    // Example: Add responsive table handling for very small screens
    function handleTableResponsiveness() {
        const tables = document.querySelectorAll('table');
        const screenWidth = window.innerWidth;

        if (screenWidth <= 480) {
            tables.forEach(table => {
                table.classList.add('mobile-table');
            });
        } else {
            tables.forEach(table => {
                table.classList.remove('mobile-table');
            });
        }
    }

    // Handle window resize
    window.addEventListener('resize', handleTableResponsiveness);

    // Initial call
    handleTableResponsiveness();

    // Add smooth scrolling for better UX
    document.documentElement.style.scrollBehavior = 'smooth';
});

// Global function to open order details in new page
function openOrderDetails(rowElement) {
    const orderId = rowElement.getAttribute('data-order-id');
    const status = rowElement.getAttribute('data-status');

    // Open order details in new page
    const orderDetailsUrl = `order-details.html?orderId=${orderId}&status=${status}`;
    window.open(orderDetailsUrl, '_blank');
} 