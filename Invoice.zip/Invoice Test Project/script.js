// Invoice Page JavaScript
document.addEventListener('DOMContentLoaded', function () {
    // Add any interactive functionality here if needed

    // Example: Add print functionality
    function printInvoice() {
        window.print();
    }

    // Example: Add responsive table handling for very small screens
    function handleTableResponsiveness() {
        const tables = document.querySelectorAll('table');
        const screenWidth = window.innerWidth;

        if (screenWidth <= 480) {
            tables.forEach(table => {
                table.classList.add('mobile-table');
            });
        } else {
            tables.forEach(table => {
                table.classList.remove('mobile-table');
            });
        }
    }

    // Handle window resize
    window.addEventListener('resize', handleTableResponsiveness);

    // Initial call
    handleTableResponsiveness();

    // Add smooth scrolling for better UX
    document.documentElement.style.scrollBehavior = 'smooth';
});

// Global function to open order details
function openOrderDetails(rowElement) {
    const orderId = rowElement.getAttribute('data-order-id');
    const status = rowElement.getAttribute('data-status');

    // Remove selection from all rows
    document.querySelectorAll('.breakdown-data').forEach(row => {
        row.classList.remove('selected');
    });

    // Add selection to clicked row
    rowElement.classList.add('selected');

    // Hide all order detail sections first
    hideAllOrderDetails();

    // Show the corresponding order detail section
    showOrderDetails(orderId, status);

    // Update button text
    updateButtonText(true);

    // Scroll to the order details section
    const orderSection = document.querySelector(`[data-order-section="${orderId}"]`);
    if (orderSection) {
        orderSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    const orderNumberDisplay = document.getElementById('dynamic-order-number');
    if (orderNumberDisplay) {
        orderNumberDisplay.textContent = `Order # ${orderId}`;
    }
}

// Function to hide all order detail sections
function hideAllOrderDetails() {
    // Hide all order details sections
    const orderSections = document.querySelectorAll('[data-order-section]');
    orderSections.forEach(section => {
        section.style.display = 'none';
    });
}

// Function to show specific order details
function showOrderDetails(orderId, status) {
    // Show the specific order section
    const orderSection = document.querySelector(`[data-order-section="${orderId}"]`);
    if (orderSection) {
        orderSection.style.display = 'block';

        // Update the order number and status in the header
        const orderNumberElement = orderSection.querySelector('.order-number');
        const orderStatusElement = orderSection.querySelector('.order-status');

        if (orderNumberElement) {
            orderNumberElement.textContent = `Order # ${orderId}`;
        }

        if (orderStatusElement) {
            orderStatusElement.textContent = `Status: ${status}`;
        }

        // Update the status styling
        updateOrderStatus(orderSection, status);

        // Show/hide refund row based on status
        const refundRow = orderSection.querySelector('.order-breakdown-refund');
        if (refundRow) {
            if (status === 'Refund') {
                refundRow.style.display = 'table-row';
            } else {
                refundRow.style.display = 'none';
            }
        }
    }
}

// Function to update order status display
function updateOrderStatus(orderSection, status) {
    const statusElement = orderSection.querySelector('.order-status');
    if (statusElement) {
        statusElement.textContent = `Status: ${status}`;

        // Add status-specific styling
        statusElement.className = 'order-status';
        if (status === 'Delivered') {
            statusElement.classList.add('status-delivered');
        } else if (status === 'Refund') {
            statusElement.classList.add('status-refund');
        }
    }

    // Show/hide Refund row based on status
    const refundRow = orderSection.querySelector('.order-breakdown-refund');
    if (refundRow) {
        if (status === 'Refund') {
            refundRow.style.display = 'table-row';
        } else {
            refundRow.style.display = 'none';
        }
    }
}

// Function to show all order details (for initial page load)
function showAllOrderDetails() {
    // Show all order details sections
    const orderSections = document.querySelectorAll('[data-order-section]');
    orderSections.forEach(section => {
        section.style.display = 'block';
    });
}

// Function to reset view and show all order details
function resetView() {
    // Remove selection from all rows
    document.querySelectorAll('.breakdown-data').forEach(row => {
        row.classList.remove('selected');
    });

    // Show all order details
    showAllOrderDetails();

    // Hide all refund rows when showing all orders
    document.querySelectorAll('.order-breakdown-refund').forEach(refundRow => {
        refundRow.style.display = 'none';
    });

    // Update button text
    updateButtonText(false);

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Function to update button text
function updateButtonText(isDetailView) {
    const resetBtn = document.querySelector('.reset-btn');
    if (resetBtn) {
        if (isDetailView) {
            resetBtn.textContent = 'Show All Orders';
        } else {
            resetBtn.textContent = 'Show All Orders';
        }
    }
}



// Initialize page with all order details hidden
document.addEventListener('DOMContentLoaded', function () {
    // Hide all order details initially
    hideAllOrderDetails();

    // Add reset button functionality if needed
    // You can add a reset button in the HTML and call resetView() on click
}); 