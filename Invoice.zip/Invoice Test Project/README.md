# Tax Invoice - My School Lunch

A pixel-perfect, fully responsive HTML invoice page that replicates the design from the provided screenshot.

## Features

- **Pixel-perfect design** matching the original screenshot
- **Fully responsive** layout for desktop, tablet, and mobile
- **Modern CSS** using Flexbox and Grid for layout
- **CSS variables** for consistent theming
- **Clean table styling** with alternating rows and proper borders
- **Professional typography** and spacing

## Structure

The invoice consists of three main sections:

1. **Main Invoice Section**
   - Header with green banner and diagonal cut
   - Details section (Details, Biller, Recipient)
   - Invoice Summary table (red header)
   - Invoice Breakdown table (orange header)
   - Footer with Vibrant Brands logo

2. **Order Breakdown Section 1**
   - Replicated header and footer
   - Order-specific breakdown table
   - Item-level details with GST calculations

3. **Order Breakdown Section 2**
   - Replicated header and footer
   - Order-specific breakdown table
   - Item-level details with GST calculations

## Responsive Breakpoints

- **Desktop**: 1024px and above
- **Tablet**: 768px - 1023px
- **Mobile**: 767px and below
- **Small Mobile**: 480px and below

## Files

- `index.html` - Main HTML structure
- `styles.css` - CSS styling with responsive design
- `script.js` - Minimal JavaScript for functionality
- `README.md` - Project documentation

## Design Elements

### Colors
- Primary Green: `#4CAF50`
- Primary Red: `#F44336`
- Primary Orange: `#FF9800`
- Light Green: `#E8F5E9`
- Light Grey: `#F5F5F5`
- Dark Grey: `#333333`

### Typography
- Font Family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif
- Base Font Size: 14px
- Responsive scaling for mobile devices

### Layout
- CSS Grid for the three-column details section
- Flexbox for header and footer alignment
- CSS Grid for logo icon arrangement
- Responsive table layouts

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- CSS Grid and Flexbox support required
- Responsive design optimized for all screen sizes

## Usage

1. Open `index.html` in a web browser
2. The page will automatically adapt to different screen sizes
3. Tables are optimized for both desktop and mobile viewing
4. Print-friendly layout (use browser print function)

## Customization

The design uses CSS variables for easy customization:
- Modify colors in the `:root` section
- Adjust spacing and typography as needed
- Update logo placeholders with actual assets
- Modify table data as required

## Notes

- Logo placeholders are currently implemented using CSS
- Replace with actual logo assets when available
- The diagonal cut in the header is implemented using CSS pseudo-elements
- All spacing and measurements are pixel-perfect to match the original design 