# Invoice Management System

A web-based invoice management system for My School Lunch with order breakdown functionality.

## Features

- **Main Invoice Page** (`index.html`): Displays invoice summary and breakdown table
- **Order Details Page** (`order-details.html`): Shows detailed order information in a new page
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Professional Styling**: Clean, modern design with consistent branding

## How to Use

1. **Main Page**: Open `index.html` to view the invoice summary and breakdown table
2. **Order Details**: Click on any row in the "Invoice Breakdown" table to open order details in a new page
3. **Navigation**: Each order detail page maintains the same header and footer styling as the main page

## File Structure

- `index.html` - Main invoice page with summary and breakdown table
- `order-details.html` - Order details page (opens in new tab/window)
- `styles.css` - Shared styling for both pages
- `script.js` - Main page JavaScript functionality
- `order-details.js` - Order details page JavaScript functionality
- `school_logo.png` - Company logo
- `visitign_card.png` - Footer logo

## Technical Details

- **Click Functionality**: Table rows have `onclick="openOrderDetails(this)"` handlers
- **Data Passing**: Order ID and status are passed via URL parameters
- **Styling Consistency**: Both pages use the same CSS file for consistent appearance
- **Responsive Design**: CSS media queries ensure proper display on all devices

## Browser Compatibility

- Modern browsers (Chrome, Firefox, Safari, Edge)
- Mobile browsers (iOS Safari, Chrome Mobile)
- Requires JavaScript enabled for full functionality 